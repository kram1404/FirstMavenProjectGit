package com.inetbanking.testCases;

public class EditCustomer {
//Edit customer
}
