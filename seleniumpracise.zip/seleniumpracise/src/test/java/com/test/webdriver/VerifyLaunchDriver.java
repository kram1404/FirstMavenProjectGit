package com.test.webdriver;

import org.openqa.selenium.WebDriver;

import com.practise.webdriver.LaunchDriver;

public class VerifyLaunchDriver {

/*	public static void main(String[] args)
	{
		WebDriver driver = null;
		LaunchDriver launch= new LaunchDriver(driver);
		String expectedTitle = "Welcome: Mercury Tours";
		String ActualUrl=" ";
		ActualUrl= driver.getTitle();
		if(ActualUrl.equalsIgnoreCase(expectedTitle))
		{
			System.out.println("Test Pass");
		}
		else
		{
		System.out.println("Test Failed");
		}
	}*/

}
