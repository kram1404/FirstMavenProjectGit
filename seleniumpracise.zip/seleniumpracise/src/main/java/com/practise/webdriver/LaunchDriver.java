package com.practise.webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchDriver {
	
	WebDriver driver;
	public LaunchDriver() {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver=new ChromeDriver();
		String BaseUrl="http://demo.guru99.com/test/newtours/";
		driver.get(BaseUrl);
		String ActualUrl="Welcome: Mercury Tours";
		String ExpectedUrl=driver.getTitle();
		if(ActualUrl.equalsIgnoreCase(ExpectedUrl))
		{
			System.out.println("Test passed");
		}
		else
		{
			System.out.println("Test Failed");
		}
		driver.close();
		}
	
	public static void main(String args[])
	{	
		LaunchDriver launch=new LaunchDriver();
	}


}
