package com.practise.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxandRadioButton 
{
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
/*		String BaseUrl="http://www.facebook.com";
		
		driver.get(BaseUrl);
		
		//CHECK BOX
		
		WebElement chkElement = driver.findElement(By.id("Persist_box"));
		for (int i=0;i<2;i++)
		{
			chkElement.click(); //When i =0, it is check and print true , when i=1, it will print false
			System.out.print(chkElement.isSelected());
		}*/
		
		/*// RADIO BUTTON
		String BaseUrl1="http://demo.guru99.com/test/radio.html";
		driver.get(BaseUrl1);
		WebElement option1=driver.findElement(By.id("vfb-6-0"));
		option1.click();
		if(option1.isSelected())
		{
			System.out.println("TRUE");
		}
		else
		{
			System.out.println("FALSE");
		}
		option1.click();
		if(!option1.isSelected())
		{
			
			System.out.println("False");
		}*/
		driver.get("http://demo.guru99.com/test/radio.html");					
        WebElement radio1 = driver.findElement(By.id("vfb-7-1"));							
        WebElement radio2 = driver.findElement(By.id("vfb-7-2"));							
        		
        //Radio Button1 is selected		
        radio1.click();			
        System.out.println("Radio Button Option 1 Selected");					
        		
        //Radio Button1 is de-selected and Radio Button2 is selected		
        radio2.click();			
        System.out.println("Radio Button Option 2 Selected");					
        		
        // Selecting CheckBox		
        WebElement option1 = driver.findElement(By.id("vfb-6-0"));							

        // This will Toggle the Check box 		
        option1.click();			

        // Check whether the Check box is toggled on 		
        if (option1.isSelected()) {					
            System.out.println("Checkbox is Toggled On");					

        } else {			
            System.out.println("Checkbox is Toggled Off");					
        }		
         
        		
        		
        //Selecting Checkbox and using isSelected Method		
        driver.get("http://demo.guru99.com/test/facebook.html");					
        WebElement chkFBPersist = driver.findElement(By.id("persist_box"));							
        for (int i=0; i<2; i++) {											
            chkFBPersist.click (); 			
            System.out.println("Facebook Persists Checkbox Status is -  "+chkFBPersist.isSelected());							
        }		
		driver.close();
	}
	
}
