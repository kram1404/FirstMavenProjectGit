package com.practise.webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class IEtestforDesiredCapabilities {

	public static void main(String[] args) {

		// it is used to define IE capability
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();

		capabilities.setCapability(CapabilityType.BROWSER_NAME, "IE");
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", "./driver/IEDriverServer.exe");

		WebDriver driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.get("http://gmail.com");

		/*
		 * Note It needs to set same Security level in all zones. To do that follow the
		 * steps below:
		 * 
		 * Open IE Go to Tools -> Internet Options -> Security Set all zones (Internet,
		 * Local intranet, Trusted sites, Restricted sites) to the same protected mode,
		 * enabled or disabled should not matter.
		 * 
		 * Finally, set Zoom level to 100% by right clicking on the gear located at the
		 * top right corner and enabling the status-bar. Default zoom level is now
		 * displayed at the lower righ
		 * 
		 */

	}
}
