# Free Selenium Webdriver Tutorial
Source code for my [free Selenium WebDriver for Java tutorial](https://testautomationu.applitools.com/selenium-webdriver-tutorial-java/) on Test Automation University. This course covers beginner to advanced topics in Selenium WebDriver.

